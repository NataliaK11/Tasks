package pl.PDF.From.Tasks.BikeRental;

public enum Colour {
    RED,GREEN,BLUE
}
