package pl.PDF.From.Tasks.Blog;

public class Comment extends Entry {

    public Comment(int id, double date, User author, String content){
        super(id, date, author, content);
    }
}
